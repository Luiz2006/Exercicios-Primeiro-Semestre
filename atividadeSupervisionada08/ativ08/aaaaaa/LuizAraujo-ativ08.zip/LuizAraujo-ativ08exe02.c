#include<stdio.h>
#include<conio.h>
#include<conio.c>
#include<locale.h>
int main(){
    setlocale(LC_ALL,"Portuguese");
    float val1, val2, val3;
    
    printf("Informe o primeiro valor: ");
    scanf("%f", &val1);
    printf("Informe o segundo valor: ");
    scanf("%f", &val2);
    printf("Informe o terceiro valor: ");
    scanf("%f", &val3);
    
    system("CLS");
    
    gotoxy(24,11); //n�o est� funcionando  o gotoxy
	
	if((val1 > val2) && (val1 > val3)){  
    	gotoxy(24,11);
        printf("O maior valor informado � o %f!", val1);
    }else{
        if((val2 > val1) && (val2 > val3)){  
            printf("O maior valor informado � o %f!", val2);
        }else{
            if((val3 > val1) && (val3 > val2)){  
                printf("O maior valor informado � o %f!", val3);
            }else{  
    			gotoxy(20,11);
                printf("N�o h� um valor maior!");
            }
        }
    }
    printf("\n\n\n\n\n\n\n\n\n\n\n\ ");
    system("PAUSE");
}
