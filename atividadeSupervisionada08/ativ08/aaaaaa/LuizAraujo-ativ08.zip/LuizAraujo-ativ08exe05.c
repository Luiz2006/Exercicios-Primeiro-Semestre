#include<stdio.h>
#include<conio.h>
int main(){
    printf("\xC9\xCD\xCD\xBB\n"); 
    printf("\xBA  \xBA\n");
    printf("\xBA  \xBA\n");
    printf("\xC8\xCD\xCD\xBC");
}

